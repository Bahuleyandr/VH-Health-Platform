// src/lib/schemas.ts
import { z } from 'zod';

/* =========================
 * User / Admin Schemas
 * ========================= */

export const UserSchema = z.object({
  id: z.number(),
  name: z.string(),
  email: z.string().email(),
  phone: z.string(),
  is_active: z.boolean(),
  created_at: z.string(), // ISO date string
  date_of_birth: z.string().optional(),
});

export const AdminRoleEnum = z.enum(['ADMIN', 'SUPER_ADMIN']);

export const AdminUserSchema = UserSchema.extend({
  role: AdminRoleEnum,
  permissions: z.array(z.string()),
  last_login: z.string(), // ISO date string
});

/* =========================
 * Domain Schemas
 * ========================= */

export const DepartmentSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().optional(),
  is_active: z.boolean().optional(),
  created_at: z.string().optional(),
});

export const DoctorSchema = z.object({
  user_id: z.number(),
  name: z.string(),
  email: z.string().email(),
  phone: z.string(),
  department: z.string(),
  specialization: z.string(),
  consultation_fee: z.number(),
  is_available: z.boolean(),
  rating: z.number().optional(),
});

export const PatientSchema = z.object({
  id: z.number(),
  name: z.string(),
  email: z.string().email(),
  phone: z.string(),
  date_of_birth: z.string().optional(),
  address: z.string().optional(),
  created_at: z.string(),
});

export const AppointmentStatusEnum = z.enum(['SCHEDULED', 'COMPLETED', 'CANCELLED']);

export const AppointmentSchema = z.object({
  id: z.number(),
  patient_id: z.number(),
  doctor_id: z.number(),
  appointment_date: z.string(), // ISO date string
  appointment_time: z.string(), // e.g., "14:30"
  status: AppointmentStatusEnum,
  notes: z.string().optional(),
  created_at: z.string(),
});

/* =========================
 * Dashboard / Backend Schemas
 * ========================= */

// What the backend returns (example)
export const DashboardDataBackendSchema = z.object({
  totalUsers: z.number(),
  activeUsers: z.number(),
  totalDoctors: z.number(),
  totalAppointments: z.number(),
  recentActivity: z
    .array(
      z.object({
        id: z.number(),
        action: z.string(),
        timestamp: z.string(), // ISO date string
        user: z.string(),
      })
    )
    .optional(),
});

// What the frontend UI expects
export const DashboardDataSchema = z.object({
  totalPatients: z.number(),
  totalAppointments: z.number(),
  activeDepartments: z.number(),
  totalStaff: z.number(),
});

/* =========================
 * Form Schemas
 * ========================= */

export const LoginFormSchema = z.object({
  username: z.string().min(1, 'Username is required'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
});

export const CreateDoctorFormSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  phone: z.string().regex(/^[0-9]{10}$/, 'Phone must be 10 digits'),
  department: z.string().min(1, 'Department is required'),
  specialization: z.string().min(1, 'Specialization is required'),
  consultation_fee: z.number().min(0, 'Fee must be positive'),
});

/* =========================
 * Type Exports (from schemas)
 * ========================= */

export type User = z.infer<typeof UserSchema>;
export type AdminUser = z.infer<typeof AdminUserSchema>;
export type Department = z.infer<typeof DepartmentSchema>;
export type Doctor = z.infer<typeof DoctorSchema>;
export type Patient = z.infer<typeof PatientSchema>;
export type Appointment = z.infer<typeof AppointmentSchema>;
export type DashboardDataBackend = z.infer<typeof DashboardDataBackendSchema>;
export type DashboardData = z.infer<typeof DashboardDataSchema>;
export type LoginForm = z.infer<typeof LoginFormSchema>;
export type CreateDoctorForm = z.infer<typeof CreateDoctorFormSchema>;
